﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoubleLinkedList
{    
    class Program
    {
        static void Main(string[] args)
        {
            Double ob = new Double();            
            int ch, ele, pos;

            do
            {
                Console.WriteLine("1 Insert at begining");
                Console.WriteLine("2 Insert at end");
                Console.WriteLine("3 Insert at given position");
                Console.WriteLine("4 Deleting at begining");
                Console.WriteLine("5 Deleting at end");
                Console.WriteLine("6 Deleting at given position");
                Console.WriteLine("7 Search an element");
                Console.WriteLine("8 Search an element occurence");
                Console.WriteLine("9 Display");
                Console.WriteLine("10 Exit");

                ch = int.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        Console.Write("Enter the element = ");
                        ele = int.Parse(Console.ReadLine());
                        ob.insertbegin(ele);
                        break;

                    case 2:
                        Console.Write("Enter the element = ");
                        ele = int.Parse(Console.ReadLine());
                        ob.insertend(ele);
                        break;

                    case 3:
                        Console.Write("Enter the element = ");
                        ele = int.Parse(Console.ReadLine());

                        do
                        {
                            Console.WriteLine("Enter postion ");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos < 1 || pos > ob.count + 1);
                  
                        ob.insertpos(ele, pos);
                        break;

                    case 4:
                        Console.Write("Enter the element = ");
                        ele = int.Parse(Console.ReadLine());
                        ob.deletebegin();
                        break;

                    case 5:
                        Console.Write("Enter the element = ");
                        ele = int.Parse(Console.ReadLine());
                        ob.deleteend();
                        break;

                    case 6:
                        do
                        {
                            Console.WriteLine("Enter postion ");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos < 1 || pos > ob.count + 1);

                        ob.deletepos(pos);
                        break;

                    case 7:
                        Console.Write("Enter search value =  ");
                        ele = int.Parse(Console.ReadLine());
                        ob.SearchElement(ele);
                        break;

                    case 8:
                        Console.Write("Enter element =  ");
                        ele = int.Parse(Console.ReadLine());
                        Console.Write("Enter occurence value = ");
                        int occ = int.Parse(Console.ReadLine());
                        pos = ob.occurence(ele,occ);
                        if (pos == -1)
                            Console.WriteLine("Search key not found");
                        else if (pos == -2)
                            Console.WriteLine("Found search key but not occurence");
                        else
                            Console.WriteLine("Search key found at {0} position", pos);
                        break;

                    case 9: ob.display();break;

                    case 10: break;

                    default: Console.WriteLine("Invalid choice");break;
                }
            } while (ch != 10);
        }
    }
}
