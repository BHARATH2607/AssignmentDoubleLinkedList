﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoubleLinkedList
{
    class Node
    {
        public Node prev;
        public int data;
        public Node next;        
    };

    class Double
    {
        public Node head;
        public int count;

        public Double()
        {
            head = null;
            count = 0;
        }

        public Node createnode(int ele)
        {
            Node temp = new Node();
            temp.data = ele;
            temp.next = null;
            temp.prev = null;
            count++;
            return temp;
        }

        public void insertbegin(int ele)
        {
            Node newnode = createnode(ele);
            if(head == null)
            {
                head = newnode;
            }
            else
            {
                head.prev = newnode;
                newnode.next = head;
                head = newnode;
            }
            count++;
        }

        public void insertend(int ele)
        {
            Node newnode = createnode(ele);
            if (head == null)
            {
                head = newnode;
            }
            else
            {
                Node temp;
                temp = head;
                while (temp.next != null)
                    temp = temp.next;
                temp.next = newnode;
                newnode.prev = temp;
            }
            count++;
        }

        public void insertpos(int ele, int pos)
        {
            Node newnode = createnode(ele);
            if (pos == 1)
                insertbegin(ele);
            else if (pos == count + 1)
                insertend(ele);
            else
            {
                Node temp;
                temp = head;
                for(int i = 1; i < pos - 1; i++)
                {
                    if(temp != null)
                    {
                        temp = temp.next;                           
                    }
                }

                if(temp != null)
                {                                 
                    newnode.next = temp.next; 
                    newnode.prev = temp;      
                    temp.next = newnode;
                    if (newnode.next != null)
                        newnode.next.prev = newnode;
                    else
                        Console.WriteLine("The previous node is null");
                }
            }
            count++;
        }

        public void deletebegin()
        {
            if (head == null)
                Console.WriteLine("No elements in list - Deletion not possible");
            else
            {
                Node temp = head;
                head = head.next;
                Console.WriteLine("Deleting the node with value = " + temp.data);
                temp = null;
                if (head != null)
                    head.prev = null;
                count--;
            }
        }

        public void deleteend()
        {
            if (head == null)
                Console.WriteLine("No elements in list - Deletion not possible");
            else
            {
                if(head.next == null)
                {
                    head = null;
                }
                else
                {
                    Node temp;
                    temp = head;
                    while (temp.next.next != null)
                        temp = temp.next;

                    Node lastNode = temp.next;
                    temp.next = null;
                    lastNode = null;
                }
            }
        }

        public void deletepos(int pos)
        {
            if (pos == 1)
                deletebegin();
            else if (pos == count)
                deleteend();
            else
            {
                Node temp;
                temp = head;
                int i = 1;
                while(i < pos)
                {
                    temp = temp.next;
                    i++;
                }
                temp.prev.next = temp.next;
                temp.next.prev = temp.prev;
            }
        }

        public void SearchElement(int ele)
        {
            Node temp = new Node();
            temp = head;
            int found = 0;
            int i = 0;

            if (temp != null)
            {
                while (temp != null)
                {
                    i++;
                    if (temp.data == ele)
                    {
                        found++;
                        break;
                    }
                    temp = temp.next;
                }
                if (found == 1)
                {
                    Console.WriteLine(ele + " is found at index = " + i);
                }
                else
                {
                    Console.WriteLine(ele + " is not found in the list.");
                }
            }
            else
            {
                Console.WriteLine("The list is empty.");
            }
        }

        public int occurence(int ele, int occ)
        {
            Node temp;
            temp = head;
            int pos = 0;
            while(temp != null)
            {
                pos++;
                if(temp.data == ele)
                {
                    count++;
                    if (count == occ)
                        return pos;                       
                }
                temp = temp.next;
            }
            if (count == 0)
                return -1;
            else
                return -2;
        }

        public void display()
        {
            if (head == null)
                Console.WriteLine("No elements in list");
            else
            {
                Console.WriteLine("\n Elements of list are : ");
                Node temp;
                temp = head;
                while (temp != null)
                {
                    Console.Write(temp.data + " \t");
                    temp = temp.next;
                }
                Console.WriteLine();
            }
        }

        public Node lastnode()
        {
            Node temp;
            temp = head;
            while (temp.next != null)
                temp = temp.next;
            return temp;
        }

        public void reverse()
        {
            if(head == null)
                Console.WriteLine("List is empty");
            else
            {
                Node lastnd = lastnode();
                while(lastnd != null)
                {
                    Console.WriteLine(lastnd.data + "\t");
                    lastnd = lastnd.prev;
                }
                Console.WriteLine();
            }
        }
    }
}
